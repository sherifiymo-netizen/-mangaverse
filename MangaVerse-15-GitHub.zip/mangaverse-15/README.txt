MangaVerse - نسخة GitHub Pages
1) ارفع index.html و style.css و app.js ومجلد assets إلى المستودع.
2) فعّل Settings > Pages > Deploy from branch > main > root.
3) الصور في assets/covers أصلية SVG مولدة لهذا المشروع.
4) الفصول والقارئ يعملان محليًا داخل الواجهة. العملات تجريبية وغير مالية.
5) النشر الحالي محلي داخل المتصفح؛ لتسجيل دخول حقيقي وقاعدة بيانات تحتاج Backend/Firebase/Supabase.
